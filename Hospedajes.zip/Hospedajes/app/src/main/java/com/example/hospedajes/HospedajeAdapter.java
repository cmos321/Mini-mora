package com.example.hospedajes;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

// Adapter de la lista: dibuja una tarjeta por cada hospedaje
public class HospedajeAdapter extends ArrayAdapter<Hospedaje> {

    public HospedajeAdapter(Context context, ArrayList<Hospedaje> lista) {
        super(context, 0, lista);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View vista = convertView;
        if (vista == null) {
            vista = LayoutInflater.from(getContext()).inflate(R.layout.item_hospedaje, parent, false);
        }

        Hospedaje h = getItem(position);

        TextView txtNombre = vista.findViewById(R.id.txtNombre);
        TextView txtUbicacion = vista.findViewById(R.id.txtUbicacion);
        TextView txtDatos = vista.findViewById(R.id.txtDatos);

        // El precio se muestra con puntos de miles (por ejemplo 50.000)
        String precio = NumberFormat.getInstance(new Locale("es", "CL")).format(h.precio);

        txtNombre.setText(h.nombre);
        txtUbicacion.setText("Ubicación: " + h.ubicacion);
        txtDatos.setText("Personas: " + h.personas + "     Precio: $" + precio);

        return vista;
    }
}
