package com.example.hospedajes;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.button.MaterialButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

// CRUD de hospedajes en Firebase Realtime Database
public class MainActivity extends AppCompatActivity {

    // Dirección de tu Realtime Database. Normalmente se deja vacía porque viene en google-services.json.
    // Solo si la app no se conecta, copia la dirección desde la consola de Firebase
    // (Build, Realtime Database, pestaña Datos) y pégala aquí entre las comillas.
    static final String URL_BASE_DATOS = "";

    // Declaración de los componentes de la interfaz
    EditText edtNombre, edtUbicacion, edtPersonas, edtPrecio;
    MaterialButton btnGuardar, btnCancelar;
    TextView txtContador, txtVacio;
    ListView listaHospedajes;

    DatabaseReference hospedajesRef;   // Nodo "hospedajes" de la base de datos
    ValueEventListener escuchador;

    ArrayList<Hospedaje> hospedajes = new ArrayList<>();
    HospedajeAdapter adaptador;

    String idEditando = null;          // null = se está creando uno nuevo; si no, el id del que se edita

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        edtNombre = findViewById(R.id.edtNombre);
        edtUbicacion = findViewById(R.id.edtUbicacion);
        edtPersonas = findViewById(R.id.edtPersonas);
        edtPrecio = findViewById(R.id.edtPrecio);
        btnGuardar = findViewById(R.id.btnGuardar);
        btnCancelar = findViewById(R.id.btnCancelar);
        txtContador = findViewById(R.id.txtContador);
        txtVacio = findViewById(R.id.txtVacio);
        listaHospedajes = findViewById(R.id.listaHospedajes);

        // ajuste de márgenes del sistema (barras de estado y navegación)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            int margen = (int) (16 * getResources().getDisplayMetrics().density); // 16dp
            v.setPadding(systemBars.left + margen, systemBars.top + margen, systemBars.right + margen, systemBars.bottom + margen);
            return insets;
        });

        adaptador = new HospedajeAdapter(this, hospedajes);
        listaHospedajes.setAdapter(adaptador);

        // Guardar (crea uno nuevo o actualiza el que se está editando)
        btnGuardar.setOnClickListener(v -> guardar());

        // Cancelar la edición
        btnCancelar.setOnClickListener(v -> limpiarFormulario());

        // Al tocar un hospedaje se elige entre editarlo o eliminarlo
        listaHospedajes.setOnItemClickListener((parent, view, position, id) ->
                mostrarOpciones(hospedajes.get(position)));

        conectarBaseDeDatos();
    }

    // READ (leer): escucha el nodo "hospedajes" en tiempo real
    void conectarBaseDeDatos() {
        try {
            FirebaseDatabase base = URL_BASE_DATOS.isEmpty()
                    ? FirebaseDatabase.getInstance()
                    : FirebaseDatabase.getInstance(URL_BASE_DATOS);
            hospedajesRef = base.getReference("hospedajes");
        } catch (Exception e) {
            // Pasa si Realtime Database no está creada o falta su dirección en google-services.json
            txtVacio.setText("No se pudo conectar con Realtime Database.\nCrea la base de datos y vuelve a descargar google-services.json");
            return;
        }

        escuchador = new ValueEventListener() {
            // Se ejecuta la primera vez y cada vez que algo cambia en la base de datos
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                hospedajes.clear();
                for (DataSnapshot hijo : snapshot.getChildren()) {
                    Long personas = hijo.child("personas").getValue(Long.class);
                    Long precio = hijo.child("precio").getValue(Long.class);
                    hospedajes.add(new Hospedaje(
                            hijo.getKey(),
                            hijo.child("nombre").getValue(String.class),
                            personas == null ? 0 : personas.intValue(),
                            precio == null ? 0 : precio,
                            hijo.child("ubicacion").getValue(String.class)));
                }
                // El hospedaje más nuevo va arriba
                Collections.reverse(hospedajes);
                adaptador.notifyDataSetChanged();

                txtContador.setText("Hospedajes guardados: " + hospedajes.size());
                txtVacio.setText("Aún no hay hospedajes");
                txtVacio.setVisibility(hospedajes.isEmpty() ? View.VISIBLE : View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MainActivity.this, "Error: " + error.getMessage(), Toast.LENGTH_LONG).show();
            }
        };
        hospedajesRef.addValueEventListener(escuchador);
    }

    // Revisa los datos del formulario y los guarda
    void guardar() {
        String nombre = edtNombre.getText().toString().trim();
        String ubicacion = edtUbicacion.getText().toString().trim();
        String personasTexto = edtPersonas.getText().toString().trim();
        String precioTexto = edtPrecio.getText().toString().trim();

        if (nombre.isEmpty() || ubicacion.isEmpty() || personasTexto.isEmpty() || precioTexto.isEmpty()) {
            Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }
        if (hospedajesRef == null) {
            Toast.makeText(this, "No hay conexión con Realtime Database", Toast.LENGTH_SHORT).show();
            return;
        }

        int personas;
        long precio;
        try {
            personas = Integer.parseInt(personasTexto);
            precio = Long.parseLong(precioTexto);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "La cantidad de personas y el precio deben ser números", Toast.LENGTH_SHORT).show();
            return;
        }
        if (personas < 1) {
            Toast.makeText(this, "Debe haber al menos 1 persona", Toast.LENGTH_SHORT).show();
            return;
        }

        Map<String, Object> datos = new HashMap<>();
        datos.put("nombre", nombre);
        datos.put("personas", personas);
        datos.put("precio", precio);
        datos.put("ubicacion", ubicacion);

        if (idEditando == null) {
            // CREATE (crear): push() genera una clave nueva y setValue() guarda los datos
            hospedajesRef.push().setValue(datos)
                    .addOnFailureListener(e -> Toast.makeText(MainActivity.this,
                            "No se pudo guardar: " + e.getMessage(), Toast.LENGTH_LONG).show());
            Toast.makeText(this, "Hospedaje creado", Toast.LENGTH_SHORT).show();
        } else {
            // UPDATE (actualizar): cambia los datos del hospedaje que tiene ese id
            hospedajesRef.child(idEditando).updateChildren(datos)
                    .addOnFailureListener(e -> Toast.makeText(MainActivity.this,
                            "No se pudo actualizar: " + e.getMessage(), Toast.LENGTH_LONG).show());
            Toast.makeText(this, "Hospedaje actualizado", Toast.LENGTH_SHORT).show();
        }
        limpiarFormulario();
    }

    // Pregunta qué hacer con el hospedaje tocado
    void mostrarOpciones(Hospedaje h) {
        String[] opciones = {"Editar", "Eliminar"};
        new AlertDialog.Builder(this)
                .setTitle(h.nombre)
                .setItems(opciones, (dialog, which) -> {
                    if (which == 0) {
                        editar(h);
                    } else {
                        confirmarEliminar(h);
                    }
                })
                .show();
    }

    // Pasa los datos del hospedaje al formulario para poder cambiarlos
    void editar(Hospedaje h) {
        idEditando = h.id;
        edtNombre.setText(h.nombre);
        edtUbicacion.setText(h.ubicacion);
        edtPersonas.setText(String.valueOf(h.personas));
        edtPrecio.setText(String.valueOf(h.precio));
        btnGuardar.setText("Actualizar hospedaje");
        btnCancelar.setVisibility(View.VISIBLE);
    }

    // Pide confirmación antes de borrar
    void confirmarEliminar(Hospedaje h) {
        new AlertDialog.Builder(this)
                .setTitle("Eliminar hospedaje")
                .setMessage("¿Seguro que quieres eliminar " + h.nombre + "?")
                .setPositiveButton("Eliminar", (dialog, which) -> eliminar(h))
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // DELETE (eliminar): borra el hospedaje de la base de datos
    void eliminar(Hospedaje h) {
        if (hospedajesRef == null) {
            return;
        }
        hospedajesRef.child(h.id).removeValue()
                .addOnFailureListener(e -> Toast.makeText(MainActivity.this,
                        "No se pudo eliminar: " + e.getMessage(), Toast.LENGTH_LONG).show());
        Toast.makeText(this, "Hospedaje eliminado", Toast.LENGTH_SHORT).show();

        // Si justo se estaba editando ese hospedaje, se limpia el formulario
        if (h.id.equals(idEditando)) {
            limpiarFormulario();
        }
    }

    // Deja el formulario vacío y vuelve al modo crear
    void limpiarFormulario() {
        idEditando = null;
        edtNombre.setText("");
        edtUbicacion.setText("");
        edtPersonas.setText("");
        edtPrecio.setText("");
        btnGuardar.setText("Guardar hospedaje");
        btnCancelar.setVisibility(View.GONE);
        edtNombre.clearFocus();
    }

    // Se deja de escuchar la base de datos al cerrar la pantalla
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (hospedajesRef != null && escuchador != null) {
            hospedajesRef.removeEventListener(escuchador);
        }
    }
}
