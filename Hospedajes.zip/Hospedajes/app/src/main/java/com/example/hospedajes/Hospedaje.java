package com.example.hospedajes;

// Modelo simple: un hospedaje guardado en Realtime Database
public class Hospedaje {

    String id;          // Clave del hospedaje en la base de datos (sirve para editar y eliminar)
    String nombre;
    int personas;       // Cantidad de personas
    long precio;
    String ubicacion;

    public Hospedaje(String id, String nombre, int personas, long precio, String ubicacion) {
        this.id = id;
        this.nombre = nombre;
        this.personas = personas;
        this.precio = precio;
        this.ubicacion = ubicacion;
    }
}
